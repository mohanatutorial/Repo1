import java.sql.*;
public class Workers_Attendance_System{
	public static void main(String args[]){
		String url="jdbc:mysql://localhost:3306/Workers_Attendance_System";
		String username="root";
		String password="root";
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			Statement clear = con.createStatement();
			clear.executeUpdate("DELETE FROM Attendance");
			clear.close();
			String sql="insert into Attendance(id,name,age,status) values(?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(sql);
			int rowsInserted =0;

			ps.setInt(1,1);
			ps.setString(2,"Ganesh");
			ps.setInt(3,38);
			ps.setString(4,"present");
			rowsInserted += ps.executeUpdate();

			ps.setInt(1,2);
			ps.setString(2,"vibin");
			ps.setInt(3,27);
			ps.setString(4,"absent");
			rowsInserted += ps.executeUpdate();

			ps.setInt(1,3);
			ps.setString(2,"aiyshu");
			ps.setInt(3,30);
			ps.setString(4,"present");
			rowsInserted += ps.executeUpdate();

			ps.setInt(1,4);
			ps.setString(2,"kaasika");
			ps.setInt(3,45);
			ps.setString(4,"present");
			rowsInserted += ps.executeUpdate();

			ps.setInt(1,5);
			ps.setString(2,"mary");
			ps.setInt(3,29);
			ps.setString(4,"absent");
			rowsInserted += ps.executeUpdate();
			
			
			


			if(rowsInserted>0){
				System.out.println("Data inserted successfully!");
			}
			else{
				System.out.println("Failed to insert data");
			}
			System.out.println("Total rows inserted: " + rowsInserted);
			String sql1="select name from Attendance where status='present'";
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(sql1);
			System.out.println("present Students:");
			while (rs.next()){
				String name=rs.getString("name");
				System.out.println("- " + name);
			}
			String count="select count(*)as present_count from Attendance where status='present'";
			ResultSet rs1=st.executeQuery(count);
			if(rs1.next()){
				int total_count=rs1.getInt("present_count");
				System.out.println("Number of present students: " + total_count);
			}
			
			rs.close();
			rs1.close();
			ps.close();
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}

/*output:
Data inserted successfully!
Total rows inserted: 5
present Students:
- Ganesh
- aiyshu
- kaasika
Number of present students: 3*/